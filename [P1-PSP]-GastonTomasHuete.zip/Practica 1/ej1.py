"""
Ejercicio 1
Escribir una función max_in_list() que tome una lista de números y devuelva el más grande."""

"""def max_in_list(lista):

    max = -2147483648 #menor numero que puede representar un INT

    for i in lista:
        if i > max:
            max = i

    return max"""

#Main()
lista_numeros = [-98, 1, 5, 67, 1000, -87, 0, 6, -23434, -243242, 244, -43242]

print(max(lista_numeros))